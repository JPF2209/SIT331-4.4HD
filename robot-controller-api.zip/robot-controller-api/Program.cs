using robot_controller_api.Persistence;
using Npgsql;
using Serilog;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddScoped<IRobotCommandDataAccess, RobotCommandADO>();
builder.Services.AddScoped<IMapDataAccess, MapADO>();

builder.Services.AddScoped<IRobotCommandDataAccess,RobotCommandRepository>();
builder.Services.AddScoped<IMapDataAccess, MapRepository>();

builder.Services.AddScoped<IRobotCommandDataAccess, RobotCommandEF>();
builder.Services.AddScoped<IMapDataAccess, MapEF>();
builder.Services.AddScoped<RobotContext>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<RobotContext>(options =>
{
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection"))
           .LogTo(Console.WriteLine, LogLevel.Information)
           .EnableSensitiveDataLogging(); // Optional
});

builder.Logging.ClearProviders();
builder.Logging.AddConsole();  // <<<< this makes sure logs go to terminal
builder.Logging.AddDebug(); 

Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()                        // still see logs in console
    .WriteTo.File("Logs/log.txt", rollingInterval: RollingInterval.Day)  // << logs to file
    .CreateLogger();

builder.Host.UseSerilog();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();



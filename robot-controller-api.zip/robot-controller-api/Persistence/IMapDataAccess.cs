namespace robot_controller_api.Persistence;
public interface IMapDataAccess
{
    void DeleteMaps(int id);
    Map GetMapByID(int check_id);
    List<Map> GetMaps();
    List<Map> GetSquareMaps();
    Map InsertRobotMaps(Map newMap);
    Map UpdateMaps(Map newMap, int id);

    Map CheckMapCoordinate(Map check_map, int x, int y);
}
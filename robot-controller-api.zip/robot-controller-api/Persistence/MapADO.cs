using Npgsql;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing.Constraints;
namespace robot_controller_api.Persistence;
public class MapADO : IMapDataAccess

{
    // Connection string is usually set in a config file for the easeof change.

    private const string CONNECTION_STRING = $"Host=localhost;Username=postgres;Password=jpf2209;Database=sit331";
    public List<Map> GetMaps()
    {
        var robotMaps = new List<Map>();
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        using var cmd = new NpgsqlCommand("SELECT * FROM robot_map;", conn);
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            int id = dr.GetInt32(0);
            int columns = dr.GetInt32(1);
            int rows = dr.GetInt32(2);
            var name = dr.GetString(3);
            var descr = dr.IsDBNull(4) ? null : dr.GetString(4);
            var c_date = dr.GetDateTime(5);
            var m_date = dr.GetDateTime(6);
            Map robotMap = new Map();
            robotMap.Id = id;
            robotMap.Columns = columns;
            robotMap.Rows = rows;
            robotMap.Name = name;
            robotMap.Description = descr;
            robotMap.CreatedDate = c_date;
            robotMap.ModifiedDate = m_date;
            robotMaps.Add(robotMap);
        }
        return robotMaps;
    }

    public List<Map> GetSquareMaps()
    {
        var Maps = new List<Map>();
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        using var cmd = new NpgsqlCommand("SELECT * FROM robot_map WHERE rows = columns;", conn);
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            int id = dr.GetInt32(0);
            int columns = dr.GetInt32(1);
            int rows = dr.GetInt32(2);
            var name = dr.GetString(3);
            var descr = dr.IsDBNull(4) ? null : dr.GetString(4);
            var c_date = dr.GetDateTime(5);
            var m_date = dr.GetDateTime(6);
            Map robotMap = new Map();
            robotMap.Id = id;
            robotMap.Columns = columns;
            robotMap.Rows = rows;
            robotMap.Name = name;
            robotMap.Description = descr;
            robotMap.CreatedDate = c_date;
            robotMap.ModifiedDate = m_date;
            Maps.Add(robotMap);
        }
        return Maps;
    }

    public Map GetMapByID(int check_id)
    {
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        using var cmd = new NpgsqlCommand("SELECT * FROM robot_map WHERE id = @val1;", conn);
        cmd.Parameters.AddWithValue("@val1", check_id);
        Map robotMap = null;
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            int id = dr.GetInt32(0);
            int columns = dr.GetInt32(1);
            int rows = dr.GetInt32(2);
            var name = dr.GetString(3);
            var descr = dr.IsDBNull(4) ? null : dr.GetString(4);
            var c_date = dr.GetDateTime(5);
            var m_date = dr.GetDateTime(6);
            robotMap = new Map();
            robotMap.Id = id;
            robotMap.Columns = columns;
            robotMap.Rows = rows;
            robotMap.Name = name;
            robotMap.Description = descr;
            robotMap.CreatedDate = c_date;
            robotMap.ModifiedDate = m_date;
        }
        return robotMap;
    }

    public Map InsertRobotMaps(Map newMap)
    {
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        List<Map> commands = GetMaps();
        foreach (Map command in commands)
        {
            if (command.Name == newMap.Name)
            {
                return null;
            }
        }
        using var cmd = new NpgsqlCommand($"INSERT INTO robot_map (columns, rows, \"Name\", description, created_date, modified_date) OVERRIDING SYSTEM VALUE VALUES(@val2, @val3, @val4, @val5, @val6, @val7) RETURNING *;", conn);
        cmd.Parameters.AddWithValue("@val2", newMap.Columns);
        cmd.Parameters.AddWithValue("@val3", newMap.Rows);
        cmd.Parameters.AddWithValue("@val4", newMap.Name);
        cmd.Parameters.AddWithValue("@val5", newMap.Description);
        cmd.Parameters.AddWithValue("@val6", DateTime.Now);
        cmd.Parameters.AddWithValue("@val7", DateTime.Now);
        cmd.ExecuteNonQuery();
        conn.Close();
        return newMap;
    }

    public Map UpdateMaps(Map newMap, int id)
    {
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        List<Map> commands = GetMaps();
        if (newMap.Name == null || newMap.Rows == null || newMap.Columns == null)
        {
            return null;
        }
        foreach (Map command in commands)
        {
            if (command.Name == newMap.Name)
            {
                return null;
            }
        }
        using var cmd = new NpgsqlCommand($"UPDATE robot_map SET columns=@val1, rows=@val2, \"Name\"=@val3, description=@val4, modified_date=@val5 WHERE id=@val6;", conn);
        cmd.Parameters.AddWithValue("@val1", newMap.Columns);
        cmd.Parameters.AddWithValue("@val2", newMap.Rows);
        cmd.Parameters.AddWithValue("@val3", newMap.Name);
        cmd.Parameters.AddWithValue("@val4", newMap.Description);
        cmd.Parameters.AddWithValue("@val5", DateTime.Now);
        cmd.Parameters.AddWithValue("@val6", id);
        cmd.ExecuteNonQuery();
        return newMap;
    }

    public void DeleteMaps(int id)
    {
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        using var cmd = new NpgsqlCommand("DELETE FROM robot_map WHERE id = @val1;", conn);
        cmd.Parameters.AddWithValue("@val1", id);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    public Map CheckMapCoordinate(Map check_map, int x, int y)
    {
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        using var cmd = new NpgsqlCommand("SELECT * FROM robot_map WHERE id = @val1 AND @val4 >= 0 AND @val4 <= @val3 AND @val5 >= 0 AND @val5 <= @val2;", conn);
        cmd.Parameters.AddWithValue("@val1", check_map.Id);
        cmd.Parameters.AddWithValue("@val2", check_map.Columns);
        cmd.Parameters.AddWithValue("@val3", check_map.Rows);
        cmd.Parameters.AddWithValue("@val4", x);
        cmd.Parameters.AddWithValue("@val5", y);
        Map robotMap = null;
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            int id = dr.GetInt32(0);
            int columns = dr.GetInt32(1);
            int rows = dr.GetInt32(2);
            var name = dr.GetString(3);
            var descr = dr.IsDBNull(4) ? null : dr.GetString(4);
            var c_date = dr.GetDateTime(5);
            var m_date = dr.GetDateTime(6);
            robotMap = new Map();
            robotMap.Id = id;
            robotMap.Columns = columns;
            robotMap.Rows = rows;
            robotMap.Name = name;
            robotMap.Description = descr;
            robotMap.CreatedDate = c_date;
            robotMap.ModifiedDate = m_date;
        }
        return robotMap;
    }
}
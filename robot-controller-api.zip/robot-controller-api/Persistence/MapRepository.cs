using Npgsql;
namespace robot_controller_api.Persistence;


public class MapRepository : IRepository, IMapDataAccess
{
    private IRepository _repo => this;
    public List<Map> GetMaps()
    {
        var commands = _repo.ExecuteReader<Map>("SELECT * FROM public.robot_map;");
        return commands;
    }

    public List<Map> GetSquareMaps()
    {
        var commands = _repo.ExecuteReader<Map>("SELECT * FROM public.robot_map WHERE rows = columns;");
        return commands;
    }

    public Map GetMapByID(int check_id)
    {
        var sqlParams = new NpgsqlParameter[]{
            new("id", check_id),
        };
        try
        {
            var command = _repo.ExecuteReader<Map>("SELECT * FROM robot_map WHERE id = @id;",sqlParams).Single();
            return command;
        }
        catch 
        {
            return null;
        }
    }

    public Map InsertRobotMaps(Map updatedCommand)
    {
        //Implement check for whether command exists already or not
        var sqlchecks = new NpgsqlParameter[]{
            new("name", updatedCommand.Name),
        };
        try
        {
            var findCommand = _repo.ExecuteReader<Map>("SELECT * FROM public.robot_map WHERE \"Name\"=@name;",sqlchecks).Single();
            return null;
        }
        catch
        {
            var sqlParams = new NpgsqlParameter[]{
            new("name", updatedCommand.Name),
            new("description", updatedCommand.Description ?? (object)DBNull.Value),
            new("columns", updatedCommand.Columns),
            new("rows", updatedCommand.Rows),
            new("createddate", DateTime.Now),
            new("modifieddate", DateTime.Now)
            };
            try
            {
                var result = _repo.ExecuteReader<Map>("INSERT INTO public.robot_map (columns, rows, \"Name\", description, created_date, modified_date) OVERRIDING SYSTEM VALUE VALUES(@columns, @rows, @name, @description, @createddate, @modifieddate) RETURNING *;",sqlParams).Single();
                return result;
            }
            catch
            {
                return null;
            }
        }       
    }

    public Map UpdateMaps(Map updatedCommand, int id)
    {
        //Implement check for whether command exists already or not
        var sqlchecks = new NpgsqlParameter[]{
            new("name", updatedCommand.Name),
        };
        try
        {
            var findCommand = _repo.ExecuteReader<Map>("SELECT * FROM public.robot_map WHERE \"Name\"= @name;",sqlchecks).Single();
            return null;
        }
        catch
        {
            var sqlParams = new NpgsqlParameter[]{
                new("id", updatedCommand.Id),
                new("columns", updatedCommand.Columns),
                new("rows", updatedCommand.Rows),
                new("name", updatedCommand.Name),
                new("description", updatedCommand.Description ?? (object)DBNull.Value),
            };
            try
            {
                var result = _repo.ExecuteReader<Map>("UPDATE public.robot_map SET columns=@columns, rows=@rows, \"Name\"=@name, description=@description, modified_date=current_timestamp WHERE id=@id;",sqlParams).Single();
                return result;
            }
            catch
            {
                //Will still work
                return updatedCommand;
            }
        }  
    }

    public void DeleteMaps(int id)
    {
        var sqlParams = new NpgsqlParameter[]{
            new("id", id)
        };
        try
        {
            var result = _repo.ExecuteReader<Map>("DELETE FROM public.robot_map WHERE id = @id;",sqlParams).Single();
        }
        catch
        {
            return;
        }
    }

    public Map CheckMapCoordinate(Map map, int x, int y)
    {
        var sqlParams = new NpgsqlParameter[]{
            new("id", map.Id),
            new("columns", map.Columns),
            new("rows", map.Rows),
            new("x", x),
            new("y", y),
        };
        try
        {
            var command = _repo.ExecuteReader<Map>("SELECT * FROM robot_map WHERE id = @id AND @x >= 0 AND @x <= @columns AND @y >= 0 AND @y <= @rows;",sqlParams).Single();
            return command;
        }
        catch
        {
            return null;
        }
    }
}
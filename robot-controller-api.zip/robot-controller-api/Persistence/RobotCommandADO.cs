using Npgsql;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing.Constraints;
namespace robot_controller_api.Persistence;
public class RobotCommandADO : IRobotCommandDataAccess

{
    // Connection string is usually set in a config file for the easeof change.

    private const string CONNECTION_STRING = $"Host=localhost;Username=postgres;Password=jpf2209;Database=sit331";
    public List<RobotCommand> GetRobotCommands()
    {
        var robotCommands = new List<RobotCommand>();
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        using var cmd = new NpgsqlCommand("SELECT * FROM robot_command", conn);
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var name = dr.GetString(1);
            var descr = dr.IsDBNull(2) ? null : dr.GetString(2);
            int id = dr.GetInt32(0);
            var iOM = dr.GetBoolean(3);
            var c_date = dr.GetDateTime(4);
            var m_date = dr.GetDateTime(5);
            RobotCommand robotCommand = new RobotCommand();
            robotCommand.Id = id;
            robotCommand.Name = name;
            robotCommand.Description = descr;
            robotCommand.ModifiedDate = m_date;
            robotCommand.CreatedDate = c_date;
            robotCommand.IsMoveCommand = iOM;
            robotCommands.Add(robotCommand);
        }
        return robotCommands;
    }

    public List<RobotCommand> GetMoveRobotCommands()
    {
        var robotCommands = new List<RobotCommand>();
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        using var cmd = new NpgsqlCommand("SELECT * FROM robot_command WHERE is_move_command = True", conn);
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var name = dr.GetString(1);
            var descr = dr.IsDBNull(2) ? null : dr.GetString(2);
            int id = dr.GetInt32(0);
            var iOM = dr.GetBoolean(3);
            var c_date = dr.GetDateTime(4);
            var m_date = dr.GetDateTime(5);
            RobotCommand robotCommand = new RobotCommand();
            robotCommand.Id = id;
            robotCommand.Name = name;
            robotCommand.Description = descr;
            robotCommand.ModifiedDate = m_date;
            robotCommand.CreatedDate = c_date;
            robotCommand.IsMoveCommand = iOM;
            robotCommands.Add(robotCommand);
        }
        return robotCommands;
    }

    public RobotCommand GetRobotCommandByID(int check_id)
    {
        var robotCommands = new List<RobotCommand>();
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        using var cmd = new NpgsqlCommand("SELECT * FROM robot_command WHERE id = @val1", conn);
        cmd.Parameters.AddWithValue("@val1", check_id);

        RobotCommand robotCommand = null;
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var name = dr.GetString(1);
            var descr = dr.IsDBNull(2) ? null : dr.GetString(2);
            int id = dr.GetInt32(0);
            var iOM = dr.GetBoolean(3);
            var c_date = dr.GetDateTime(4);
            var m_date = dr.GetDateTime(5);
            robotCommand = new RobotCommand();
            robotCommand.Id = id;
            robotCommand.Name = name;
            robotCommand.Description = descr;
            robotCommand.ModifiedDate = m_date;
            robotCommand.CreatedDate = c_date;
            robotCommand.IsMoveCommand = iOM;
        }
        return robotCommand;
    }

    public RobotCommand InsertRobotCommands(RobotCommand newCommand)
    {
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        List<RobotCommand> commands = GetRobotCommands();
        foreach (RobotCommand command in commands)
        {
            if (command.Name == newCommand.Name)
            {
                return null;
            }
        }
        using var cmd = new NpgsqlCommand($"INSERT INTO robot_command (\"Name\", description, is_move_command, created_date, modified_date) OVERRIDING SYSTEM VALUE VALUES(@val2, @val3, @val4, @val5, @val6) RETURNING *;", conn);
        cmd.Parameters.AddWithValue("@val2", newCommand.Name);
        cmd.Parameters.AddWithValue("@val3", newCommand.Description);
        cmd.Parameters.AddWithValue("@val4", newCommand.IsMoveCommand);
        cmd.Parameters.AddWithValue("@val5", DateTime.Now);
        cmd.Parameters.AddWithValue("@val6", DateTime.Now);
        cmd.ExecuteNonQuery();
        conn.Close();
        newCommand.ModifiedDate = DateTime.Now;
        newCommand.CreatedDate = DateTime.Now;
        return newCommand;
    }

    public RobotCommand UpdateRobotCommands(RobotCommand newCommand, int id)
    {
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        List<RobotCommand> commands = GetRobotCommands();
        if (newCommand.Name == null || (newCommand.IsMoveCommand != true && newCommand.IsMoveCommand != false))
        {
            return null;
        }
        foreach (RobotCommand command in commands)
        {
            if (command.Name == newCommand.Name)
            {
                return null;
            }
        }
        using var cmd = new NpgsqlCommand($"UPDATE robot_command SET \"Name\"=@val1, description=@val2, is_move_command=@val3, modified_date=@val4 WHERE id=@val5;", conn);
        cmd.Parameters.AddWithValue("@val1", newCommand.Name);
        cmd.Parameters.AddWithValue("@val2", newCommand.Description);
        cmd.Parameters.AddWithValue("@val3", newCommand.IsMoveCommand);
        cmd.Parameters.AddWithValue("@val4", DateTime.Now);
        cmd.Parameters.AddWithValue("@val5", id);
        cmd.ExecuteNonQuery();
        return newCommand;
    }

    public void DeleteRobotCommands(int id)
    {
        using var conn = new NpgsqlConnection(CONNECTION_STRING);
        conn.Open();
        using var cmd = new NpgsqlCommand("DELETE FROM robot_command WHERE id = @val1;", conn);
        cmd.Parameters.AddWithValue("@val1", id);
        cmd.ExecuteNonQuery();
        conn.Close();
    }
}
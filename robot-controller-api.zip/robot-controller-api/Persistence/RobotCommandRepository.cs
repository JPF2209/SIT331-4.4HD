using Npgsql;
namespace robot_controller_api.Persistence;


public class RobotCommandRepository : IRepository, IRobotCommandDataAccess
{
    private IRepository _repo => this;
    public List<RobotCommand> GetRobotCommands()
    {
        var commands = _repo.ExecuteReader<RobotCommand>("SELECT * FROM public.robotcommand");
        return commands;
    }

    public List<RobotCommand> GetMoveRobotCommands()
    {
        var commands = _repo.ExecuteReader<RobotCommand>("SELECT * FROM robotcommand WHERE ismovecommand = True");
        return commands;
    }

    public RobotCommand GetRobotCommandByID(int check_id)
    {
        var sqlParams = new NpgsqlParameter[]{
            new("id", check_id),
        };
        try
        {
            var command = _repo.ExecuteReader<RobotCommand>("SELECT * FROM robotcommand WHERE id = @id",sqlParams).Single();
            return command;
        }
        catch
        {
            return null;
        }
    }

    public RobotCommand InsertRobotCommands(RobotCommand updatedCommand)
    {
        var sqlchecks = new NpgsqlParameter[]{
            new("name", updatedCommand.Name),
        };
        try
        {
            var findCommand = _repo.ExecuteReader<Map>("SELECT * FROM public.robotcommand WHERE \"Name\"=@name;",sqlchecks).Single();
            return null;
        }
        catch
        {
            var sqlParams = new NpgsqlParameter[]{
                new("name", updatedCommand.Name),
                new("description", updatedCommand.Description ?? (object)DBNull.Value),
                new("ismovecommand", updatedCommand.IsMoveCommand),
                new("createddate", DateTime.Now),
                new("modifieddate", DateTime.Now)
            };
            try
            {
                var result = _repo.ExecuteReader<RobotCommand>("INSERT INTO robotcommand (\"Name\", description, ismovecommand, createddate, modifieddate) OVERRIDING SYSTEM VALUE VALUES(@name, @description, @ismovecommand, @createddate, @modifieddate) RETURNING *;",sqlParams).Single();
                return result;
            }
            catch
            {
                return null;
            }
        }
    }

    public RobotCommand UpdateRobotCommands(RobotCommand updatedCommand, int id)
    {
        var sqlchecks = new NpgsqlParameter[]{
            new("name", updatedCommand.Name),
        };
        try
        {
            var findCommand = _repo.ExecuteReader<Map>("SELECT * FROM public.robotcommand WHERE \"Name\"=@name;",sqlchecks).Single();
            return null;
        }
        catch
        {
            var sqlParams = new NpgsqlParameter[]{
                new("id", id),
                new("name", updatedCommand.Name),
                new("description", updatedCommand.Description ?? (object)DBNull.Value),
                new("ismovecommand", updatedCommand.IsMoveCommand)
            };
            try
            {
                var result = _repo.ExecuteReader<RobotCommand>("UPDATE robotcommand SET \"Name\"=@name, description=@description, ismovecommand=@ismovecommand, modifieddate=current_timestamp WHERE id=@id RETURNING *;",sqlParams).Single();
                return result;
            }
            catch
            {
                //Will still work
                return updatedCommand;
            }
            
        }
    }

    public void DeleteRobotCommands(int id)
    {
        var sqlParams = new NpgsqlParameter[]{
            new("id", id)
        };
        try
        {
        var result = _repo.ExecuteReader<RobotCommand>("DELETE FROM robotcommand WHERE id = @id;",sqlParams).Single();
        }
        catch
        {
            return;
        }
    }
}
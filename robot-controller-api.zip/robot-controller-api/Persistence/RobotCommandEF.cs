using System.Collections.Generic;
using System.Linq;
using robot_controller_api.Models;
using Microsoft.EntityFrameworkCore;
namespace robot_controller_api.Persistence
{
    public class RobotCommandEF : IRobotCommandDataAccess
    {
        private readonly RobotContext _context;

        public RobotCommandEF(RobotContext context)
        {
            _context = context;
        }

        public List<RobotCommand> GetRobotCommands()
        {
            return _context.Robotcommands.ToList();
        }

        public RobotCommand GetRobotCommandByID(int id)
        {
            return _context.Robotcommands.FirstOrDefault(c => c.Id == id);
        }

        public List<RobotCommand> GetMoveRobotCommands()
        {
            return _context.Robotcommands.Where(c => c.IsMoveCommand == true).ToList();
        }

        public RobotCommand InsertRobotCommands(RobotCommand command)
        {
            command.CreatedDate = DateTime.Now;
            command.ModifiedDate = DateTime.Now;
            _context.Robotcommands.Add(command);
            _context.SaveChanges();
            return command;
        }

        public RobotCommand UpdateRobotCommands(RobotCommand command, int position)
        {
            var tracked = _context.ChangeTracker.Entries<RobotCommand>().FirstOrDefault(e => e.Entity.Id == command.Id);

            if (tracked != null)
            {
                tracked.State = EntityState.Detached;
            }
            else
            {
                return null;
            }


            command.ModifiedDate = DateTime.Now;
            command.Id = position;
            _context.Robotcommands.Update(command);
            _context.SaveChanges();
            return command;
        }

        public void DeleteRobotCommands(int id)
        {
            var command = _context.Robotcommands.FirstOrDefault(c => c.Id == id);
            if (command != null)
            {
                _context.Robotcommands.Remove(command);
                _context.SaveChanges();
            }
        }
    }
}

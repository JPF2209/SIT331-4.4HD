using Microsoft.AspNetCore.Mvc;

namespace robot_controller_api.Controllers;
using robot_controller_api.Persistence;

[ApiController]
[Route("api/maps")]
public class MapController : ControllerBase
{
    private readonly IMapDataAccess _mapsRepo;
    public MapController(IMapDataAccess mapsRepo)
    {
        _mapsRepo = mapsRepo;
    }

    [HttpGet("")]
    public IEnumerable<Map> GetAllMaps()
    {
        return  _mapsRepo.GetMaps();
    }

    [HttpGet("square")]
    public IEnumerable<Map> GetSquareMapsOnly()
    {
        return  _mapsRepo.GetSquareMaps();
    }

    [HttpGet("{id}",  Name =  "GetMap")]
    public IActionResult GetMapById (int id)
    {
        Map map =  _mapsRepo.GetMapByID(id);
        if (map == null)
        {
            return NotFound();
        }
        else
        {
            return Ok(map);
        }
    }

    [HttpPost()]
    public IActionResult AddMap (Map newMap)
    {
        if (newMap == null)
        {
            return BadRequest();
        }
        Map map =  _mapsRepo.InsertRobotMaps(newMap);
        if (map == null)
        {
            return Conflict();
        }
        else
        {
            return CreatedAtRoute("GetMap", new {id = map.Id}, map); 
        }
    }

    [HttpPut("{id}")]
    public IActionResult UpdateMap(int id, Map updatedMap)
    {
        Map foundMap =  _mapsRepo.GetMapByID(id);
        //Makes sure map isn't empty
        if (foundMap == null)
        {
            return NotFound();
        }
        //Checks if a new map has been able to been made
        Map newMap =  _mapsRepo.UpdateMaps(updatedMap, id);
        if (newMap == null)
        {
            return BadRequest();
        }
        else
        {            
            return NoContent();
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteMap(int id)
    {
        Map foundMap =  _mapsRepo.GetMapByID(id);
        //Checks if map exists or not
        if (foundMap == null)
        {
            return NotFound();
        }        
         _mapsRepo.DeleteMaps(id);
        return NoContent();
    }
    [HttpGet("{id}/{x}/{y}")]
    public IActionResult CheckCoordinate (int id, int x, int y)
    {
        //Checks if map is empty or if the x or y values are less than 0
        Map foundMap =  _mapsRepo.GetMapByID(id);
        if (foundMap == null)
        {
            return NotFound();
        }
        else if (x < 0 || y < 0)
        {
            return BadRequest();
        }
        else
        {
            bool isOnMap = false;            
            Map verifyMap =  _mapsRepo.CheckMapCoordinate(foundMap, x, y);
            //Check if coordinates are true using if the map can be made or not
            if (verifyMap != null)
            {
                isOnMap = true;
            }
            return Ok(isOnMap);
        }
    }
}

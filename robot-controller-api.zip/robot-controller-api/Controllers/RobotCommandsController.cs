using Microsoft.AspNetCore.Mvc;

namespace robot_controller_api.Controllers;
using robot_controller_api.Persistence;

[ApiController]
[Route("api/robot-commands")]
public class RobotCommandsController : ControllerBase
{
    private readonly IRobotCommandDataAccess _robotCommandsRepo;
    public RobotCommandsController(IRobotCommandDataAccess robotCommandsRepo)
    {
        _robotCommandsRepo = robotCommandsRepo;
    }

    [HttpGet("")]
    public IEnumerable<RobotCommand> GetRobotCommands()
    {
        return  _robotCommandsRepo.GetRobotCommands();
    }

    [HttpGet("move")]
    public IEnumerable<RobotCommand> GetMoveCommandsOnly()
    {
        return  _robotCommandsRepo.GetMoveRobotCommands();
    }

    [HttpGet("{id}", Name =  "GetRobotCommand")]
    public IActionResult GetRobotCommandById (int id)
    {
        RobotCommand command =  _robotCommandsRepo.GetRobotCommandByID(id);
        if (command == null)
        {
            return NotFound();
        }
        else
        {
            return Ok(command);
        }
    }

    [HttpPost()]
    public IActionResult AddRobotCommand (RobotCommand newCommand)
    {
        if (newCommand == null)
        {
            return BadRequest();
        }
        RobotCommand command =  _robotCommandsRepo.InsertRobotCommands(newCommand);
        if (command == null)
        {
            return Conflict();
        }
        else
        {
            return CreatedAtRoute("GetRobotCommand", new {id = command.Id}, command); 
        }
    }

    [HttpPut("{id}")]
    public IActionResult UpdateRobotCommand(int id, RobotCommand updatedCommand)
    {
        RobotCommand foundCommand =  _robotCommandsRepo.GetRobotCommandByID(id);
        //Makes sure robot isn't empty
        if (foundCommand == null)
        {
            return NotFound();
        }
        //Checks if a new robot has been able to been made
        RobotCommand newCommand =  _robotCommandsRepo.UpdateRobotCommands(updatedCommand, id);
        if (newCommand == null)
        {
            return BadRequest();
        }
        else
        {            
            return NoContent();
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteRobotCommand(int id)
    {
        RobotCommand foundCommand =  _robotCommandsRepo.GetRobotCommandByID(id);
        //Checks if robot exists or not
        if (foundCommand == null)
        {
            return NotFound();
        }        
         _robotCommandsRepo.DeleteRobotCommands(id);
        return NoContent();
    }
}

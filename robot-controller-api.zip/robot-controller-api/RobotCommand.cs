namespace robot_controller_api;

public class RobotCommand
{
    public int Id { get; set; } 
    public string Name { get; set; }    
    public string Description { get; set; } 
    public bool IsMoveCommand{ get; set; }  
    public DateTime CreatedDate{ get; set; }    
    public DateTime ModifiedDate{ get; set; }   

    public RobotCommand()
    {
        Id = -1;
        Name = "Name";
        Description = "Description";
        IsMoveCommand = true;
        CreatedDate = DateTime.Now;
        ModifiedDate = DateTime.Now;
    }
}



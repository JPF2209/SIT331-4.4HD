--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.8

-- Started on 2025-05-02 07:53:13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 221 (class 1259 OID 24777)
-- Name: loginmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loginmodel (
    email character varying(100) NOT NULL,
    password character varying(100) NOT NULL
);


ALTER TABLE public.loginmodel OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16562)
-- Name: robot_command; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_command (
    id integer NOT NULL,
    "Name" character varying(50) NOT NULL,
    description character varying(800),
    is_move_command boolean NOT NULL,
    created_date timestamp without time zone NOT NULL,
    modified_date timestamp without time zone NOT NULL
);


ALTER TABLE public.robot_command OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16568)
-- Name: robot_map; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.robot_map (
    id integer NOT NULL,
    columns integer NOT NULL,
    rows integer NOT NULL,
    "Name" character varying(50) NOT NULL,
    description character varying(800),
    created_date timestamp without time zone NOT NULL,
    modified_date timestamp without time zone NOT NULL
);


ALTER TABLE public.robot_map OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 16561)
-- Name: robotcommand_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.robot_command ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.robotcommand_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 217 (class 1259 OID 16567)
-- Name: robotmap_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.robot_map ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.robotmap_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 220 (class 1259 OID 24772)
-- Name: usermodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usermodel (
    id integer NOT NULL,
    email character varying(100) NOT NULL,
    firstname character varying(100) NOT NULL,
    lastname character varying(100) NOT NULL,
    passwordhash character varying(100) NOT NULL,
    description character varying(800),
    role character varying(800),
    createddate timestamp without time zone NOT NULL,
    modifieddate timestamp without time zone NOT NULL
);


ALTER TABLE public.usermodel OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 24771)
-- Name: usermodel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.usermodel ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.usermodel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 4902 (class 0 OID 24777)
-- Dependencies: 221
-- Data for Name: loginmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loginmodel (email, password) FROM stdin;
email@email.com	1234
\.


--
-- TOC entry 4897 (class 0 OID 16562)
-- Dependencies: 216
-- Data for Name: robot_command; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_command (id, "Name", description, is_move_command, created_date, modified_date) FROM stdin;
1	MOVE1	Moves robot forward	t	2025-04-01 16:05:22.705079	2025-04-01 16:05:22.709291
4	MOVE4	Moves robot forward	t	2025-04-01 16:05:59.228385	2025-04-01 16:05:59.228394
6	LEFT	Moves robot left	t	2025-04-03 20:46:56.396005	2025-04-03 20:46:56.404835
7	RIGHT	Moves robot left	f	2025-04-08 07:38:29.650846	2025-04-08 07:38:29.662303
13	SLIDE_RIGHT	Moves robot left	f	2025-04-15 14:28:15.14931	2025-04-15 14:28:15.149446
2	DANCE	Salsa on the Moon	t	2025-04-01 16:05:26.952022	2025-04-15 14:46:18.354704
14	DANCE1	Salsa on the Moon	t	2025-04-16 07:52:23.461237	2025-04-16 07:52:23.46203
\.


--
-- TOC entry 4899 (class 0 OID 16568)
-- Dependencies: 218
-- Data for Name: robot_map; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.robot_map (id, columns, rows, "Name", description, created_date, modified_date) FROM stdin;
1	7	7	ASTEROID1	A big asteroid	2025-04-01 16:07:14.560864	2025-04-01 16:07:14.560869
3	7	7	ASTEROID3	A big asteroid	2025-04-01 16:07:20.650374	2025-04-01 16:07:20.650381
5	5	1	ASTEROID5	A big asteroid	2025-04-01 16:07:33.456213	2025-04-01 16:07:33.456218
2	6	7	Planet	A big planet	2025-04-01 16:07:17.59476	2025-04-01 16:07:54.233033
6	5	6	ASTEROID6	A big asteroid	2025-04-01 16:08:21.898793	2025-04-01 16:08:21.898802
15	5	6	BIGPLANET1	A big asteroid	2025-04-09 18:25:56.71983	2025-04-09 18:25:56.719836
19	10	10	MERCURY	string	2025-04-29 16:21:04.730379	2025-04-29 16:50:44.584714
\.


--
-- TOC entry 4901 (class 0 OID 24772)
-- Dependencies: 220
-- Data for Name: usermodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usermodel (id, email, firstname, lastname, passwordhash, description, role, createddate, modifieddate) FROM stdin;
2	email@email.com	tommy	jason	fU8UNfbK7pmLVbCci5s1T413WcM271gg/uEdtOs8/jkj7Mr8BZsSA9pmCpGMJGf/DN09nJxCuAwaoTuekgKBGQ==	A generic user of the environment	User	2025-04-20 17:12:50.749987	2025-04-21 22:09:55.945018
1	sample@email.com	tommy	johnson	rM6vSQmUgOo4ksDZHI+ahHU8wokb+v2KaxVrXV+GCqmVzn+zKY7Yln1oEPKD2dMVFdRvuoIaIp/2cReFOEH8kQ==	A generic user of the environment	Admin	2025-04-15 21:41:11.465	2025-04-24 11:41:14.486107
3	newsample@email.com	tommy	johnson	hash	A generic user of the environment	User	2025-04-24 11:53:03.779851	2025-04-24 11:53:03.779952
\.


--
-- TOC entry 4908 (class 0 OID 0)
-- Dependencies: 215
-- Name: robotcommand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robotcommand_id_seq', 15, true);


--
-- TOC entry 4909 (class 0 OID 0)
-- Dependencies: 217
-- Name: robotmap_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.robotmap_id_seq', 20, true);


--
-- TOC entry 4910 (class 0 OID 0)
-- Dependencies: 219
-- Name: usermodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usermodel_id_seq', 3, true);


--
-- TOC entry 4752 (class 2606 OID 24783)
-- Name: robot_map pk_map; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_map
    ADD CONSTRAINT pk_map PRIMARY KEY (id);


--
-- TOC entry 4750 (class 2606 OID 24781)
-- Name: robot_command pk_robotcommand; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.robot_command
    ADD CONSTRAINT pk_robotcommand PRIMARY KEY (id);


-- Completed on 2025-05-02 07:53:13

--
-- PostgreSQL database dump complete
--


using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;

public class CustomScaffolder
{
    private string _connectionString = "Host=localhost;Database=sit331;Username=postgres;Password=jpf2209";

    public void ScaffoldModel(string templateFolderPath)
    {
        var modelData = GetTableMetadata();

        Console.WriteLine(modelData.Classes[0].Properties);

        // Initialize Handlebars
        var handlebars = HandlebarsDotNet.Handlebars.Create();

        // Define the path to the template
        var templateFilePath = Path.Combine(templateFolderPath, "class.hbs");

        if (!File.Exists(templateFilePath))
        {
            Console.WriteLine($"Template file '{templateFilePath}' not found.");
            return;
        }

        // Read the template content
        var templateContent = File.ReadAllText(templateFilePath);

        // Compile the template
        HandlebarsDotNet.HandlebarsTemplate<object, object> template = null;
        try
        {
            template = handlebars.Compile(templateContent);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error compiling template: {ex.Message}");
            return;
        }

        // Generate each class and save to Models/Classes directory
        foreach (var classData in modelData.Classes)
        {
            // Create the directory if it doesn't exist
            var outputDirectory = Path.Combine("Models");
            Directory.CreateDirectory(outputDirectory);

            // Pass the class data to Handlebars and generate the class
            var result = template(new { ClassName = classData.ClassName, Properties = classData.Properties });

            // Define the output file path
            var outputFilePath = Path.Combine(outputDirectory, $"{classData.ClassName}.cs");

            // Save the result to a file
            File.WriteAllText(outputFilePath, result);
            Console.WriteLine($"Class '{classData.ClassName}' generated and saved to {outputFilePath}");
        }
    }


    public dynamic GetTableMetadata()
    {
        var classes = new List<object>();

        using (var connection = new NpgsqlConnection(_connectionString))
        {
            connection.Open();

            // Get the table names (e.g., robot_map, robot_command)
            var tableNames = new List<string> { "robot_map", "robot_command" }; // Hardcoded for your case, but could be dynamic

            foreach (var table in tableNames)
            {
                var columns = GetTableColumns(connection, table);

                // Add each class and its properties to the model data
                classes.Add(new
                {
                    ClassName = ConvertToClassName(table),
                    Properties = columns
                });
            }
        }

        return new { Classes = classes };
    }

    private List<object> GetTableColumns(NpgsqlConnection connection, string tableName)
    {
        var columns = new List<object>();

        // Query to get the column names and types for the given table
        string query = $@"
            SELECT column_name, data_type
            FROM information_schema.columns
            WHERE table_name = '{tableName}'
            ORDER BY ordinal_position;";

        using (var cmd = new NpgsqlCommand(query, connection))
        using (var reader = cmd.ExecuteReader())
        {
            while (reader.Read())
            {
                var columnName = reader.GetString(0); // Column name
                var columnType = reader.GetString(1); // Column data type

                // Convert the column name to PascalCase for the property name
                string propertyName = ConvertToClassName(columnName);

                // Add the column type and name to the list
                columns.Add(new { ColumnName = propertyName, ColumnType = MapToCSharpType(columnType) });
            }
        }


        return columns;
    }

    private string MapToCSharpType(string columnType)
    {
        switch (columnType.ToLower())
        {
            case "integer":
                return "int";
            case "character varying":
            case "text":
                return "string?";
            case "timestamp without time zone":
            case "timestamp with time zone":
                return "DateTime";
            case "boolean":
                return "bool";
            case "double precision":
                return "double";
            // Add more types as needed
            default:
                return "string?"; // Default to string for unknown types
        }
    }




    private string ConvertToClassName(string tableName)
    {
        // Ensure the tableName is not null or empty
        if (string.IsNullOrEmpty(tableName))
            return string.Empty;

        // Convert snake_case to PascalCase
        var words = tableName.Split('_')
                            .Where(word => !string.IsNullOrEmpty(word))  // Remove any empty words
                            .Select(word => char.ToUpper(word[0]) + (word.Length > 1 ? word.Substring(1).ToLower() : ""))
                            .ToArray();
                            
        return string.Join("", words);
    }

}


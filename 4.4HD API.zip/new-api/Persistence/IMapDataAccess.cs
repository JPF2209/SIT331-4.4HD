namespace robot_controller_api.Persistence;
public interface IMapDataAccess
{
    void DeleteMaps(int id);
    RobotMap GetMapByID(int check_id);
    List<RobotMap> GetMaps();
    List<RobotMap> GetSquareMaps();
    RobotMap InsertRobotMaps(RobotMap newMap);
    RobotMap UpdateMaps(RobotMap newMap, int id);

    RobotMap CheckMapCoordinate(RobotMap check_map, int x, int y);
}
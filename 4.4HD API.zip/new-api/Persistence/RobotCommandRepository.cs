using Npgsql;
namespace robot_controller_api.Persistence;


public class RobotCommandRepository : IRepository, IRobotCommandDataAccess
{
    private IRepository _repo => this;
    public List<RobotCommand> GetRobotCommands()
    {
        var commands = _repo.ExecuteReader<RobotCommand>("SELECT * FROM public.robot_command");
        return commands;
    }

    public List<RobotCommand> GetMoveRobotCommands()
    {
        var commands = _repo.ExecuteReader<RobotCommand>("SELECT * FROM robot_command WHERE ismovecommand = True");
        return commands;
    }

    public RobotCommand GetRobotCommandByID(int check_id)
    {
        var sqlParams = new NpgsqlParameter[]{
            new("id", check_id),
        };
        try
        {
            var command = _repo.ExecuteReader<RobotCommand>("SELECT * FROM robot_command WHERE id = @id",sqlParams).Single();
            return command;
        }
        catch
        {
            return null;
        }
    }

    public RobotCommand InsertRobotCommands(RobotCommand updatedCommand)
    {
        var sqlchecks = new NpgsqlParameter[]{
            new("name", updatedCommand.Name),
        };
        try
        {
            var findCommand = _repo.ExecuteReader<RobotCommand>("SELECT * FROM public.robot_command WHERE \"Name\"=@name;",sqlchecks).Single();
            return null;
        }
        catch
        {
            var sqlParams = new NpgsqlParameter[]{
                new("name", updatedCommand.Name),
                new("description", updatedCommand.Description ?? (object)DBNull.Value),
                new("ismovecommand", updatedCommand.IsMoveCommand),
                new("createddate", DateTime.Now),
                new("modifieddate", DateTime.Now)
            };
            try
            {
                var result = _repo.ExecuteReader<RobotCommand>("INSERT INTO robot_command (\"Name\", description, is_move_command, created_date, modified_date) OVERRIDING SYSTEM VALUE VALUES(@name, @description, @ismovecommand, @createddate, @modifieddate) RETURNING *;",sqlParams).Single();
                return result;
            }
            catch
            {
                return null;
            }
        }
    }

    public RobotCommand UpdateRobotCommands(RobotCommand updatedCommand, int id)
    {
        var sqlchecks = new NpgsqlParameter[]{
            new("name", updatedCommand.Name),
        };
        try
        {
            var findCommand = _repo.ExecuteReader<RobotCommand>("SELECT * FROM public.robot_command WHERE \"Name\"=@name;",sqlchecks).Single();
            return null;
        }
        catch
        {
            var sqlParams = new NpgsqlParameter[]{
                new("id", id),
                new("name", updatedCommand.Name),
                new("description", updatedCommand.Description ?? (object)DBNull.Value),
                new("ismovecommand", updatedCommand.IsMoveCommand)
            };
            try
            {
                var result = _repo.ExecuteReader<RobotCommand>("UPDATE robot_command SET \"Name\"=@name, description=@description, is_move_command=@ismovecommand, modified_date=current_timestamp WHERE id=@id RETURNING *;",sqlParams).Single();
                return result;
            }
            catch
            {
                //Will still work
                return updatedCommand;
            }
            
        }
    }

    public void DeleteRobotCommands(int id)
    {
        var sqlParams = new NpgsqlParameter[]{
            new("id", id)
        };
        try
        {
        var result = _repo.ExecuteReader<RobotCommand>("DELETE FROM robot_command WHERE id = @id;",sqlParams).Single();
        }
        catch
        {
            return;
        }
    }
}
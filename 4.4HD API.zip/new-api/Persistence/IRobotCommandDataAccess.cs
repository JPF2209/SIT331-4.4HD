namespace robot_controller_api.Persistence;
public interface IRobotCommandDataAccess

{
    void DeleteRobotCommands(int id);
    List<RobotCommand> GetMoveRobotCommands();
    RobotCommand GetRobotCommandByID(int check_id);
    List<RobotCommand> GetRobotCommands();
    RobotCommand InsertRobotCommands(RobotCommand newCommand);
    RobotCommand UpdateRobotCommands(RobotCommand newCommand, int id);
}
using System.Collections.Generic;
using System.Linq;
using robot_controller_api.Models;
using Microsoft.EntityFrameworkCore;


namespace robot_controller_api.Persistence
{
    public class MapEF : IMapDataAccess
    {
        private readonly RobotContext _context;

        public MapEF(RobotContext context)
        {
            _context = context;
        }

        public List<RobotMap> GetMaps()
        {
            return _context.Robotmaps.ToList();
        }

        public List<RobotMap> GetSquareMaps()
        {
            return _context.Robotmaps.Where(m => m.Rows == m.Columns).ToList();
        }

        public RobotMap GetMapByID(int id)
        {
            return _context.Robotmaps.FirstOrDefault(m => m.Id == id);
        }

        public RobotMap InsertRobotMaps(RobotMap map)
        {
            map.CreatedDate = DateTime.Now;
            map.ModifiedDate = DateTime.Now;
            _context.Robotmaps.Add(map);
            _context.SaveChanges();
            return map;
        }

        public RobotMap UpdateMaps(RobotMap map, int position)
        {
            var tracked = _context.ChangeTracker.Entries<RobotMap>().FirstOrDefault(e => e.Entity.Id == map.Id);

            if (tracked != null)
            {
                tracked.State = EntityState.Detached;
            }
            else
            {
                return null;
            }


            map.ModifiedDate = DateTime.Now;
            map.Id = position;
            _context.Robotmaps.Update(map);
            _context.SaveChanges();
            return map;
        }

        public void DeleteMaps(int id)
        {
            var map = _context.Robotmaps.FirstOrDefault(m => m.Id == id);
            if (map != null)
            {
                _context.Robotmaps.Remove(map);
                _context.SaveChanges();
            }
        }

        public RobotMap CheckMapCoordinate(RobotMap check_map, int x, int y)
        {
            if (x < 0 || y < 0)
            {
                return null;
            }
            return _context.Robotmaps.FirstOrDefault(m => m.Columns >= x && m.Rows >= y);
        }
    }
}

namespace robot_controller_api;

// public class Map
// {
//     public int Id { get; set; } 
//     public int Columns { get; set; } 
//     public int Rows { get; set; } 
//     public string Name { get; set; }    
//     public string Description { get; set; }   
//     public DateTime CreatedDate{ get; set; }    
//     public DateTime ModifiedDate{ get; set; }   

//     public Map()
//     {
//         Id = -1;
//         Columns = 1;
//         Rows = 1;
//         Name = "name";
//         Description = "description";
//         CreatedDate = DateTime.Now;
//         ModifiedDate = DateTime.Now;
//     }
// }
